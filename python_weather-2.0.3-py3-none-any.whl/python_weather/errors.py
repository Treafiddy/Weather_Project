class Error(Exception):
  """Represents a ``python_weather`` error class. Extends :py:class:`Exception`."""

  __slots__ = ()
